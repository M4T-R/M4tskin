# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcvfs

SKIN_ID = "skin.arctic.fuse.2"
REQUIRED_SKIN = "skin.estuary"  # injection autorisée uniquement sur Estuary

def ok(title, msg):
    xbmcgui.Dialog().ok(title, msg)

def copy_tree(src, dst):
    if not xbmcvfs.exists(dst):
        xbmcvfs.mkdirs(dst)

    dirs, files = xbmcvfs.listdir(src)
    for d in dirs:
        copy_tree(src + d + "/", dst + d + "/")

    for f in files:
        # supprime avant pour éviter cache/verrouillage
        try:
            if xbmcvfs.exists(dst + f):
                xbmcvfs.delete(dst + f)
        except Exception:
            pass
        xbmcvfs.copy(src + f, dst + f)

def apply_pack():
    # Source du pack (dans l'addon)
    SRC_ROOT = "special://home/addons/program.m4tskin/resources/config_pack/userdata/addon_data/"
    SRC_REAL = xbmcvfs.translatePath(SRC_ROOT)

    if not xbmcvfs.exists(SRC_REAL):
        ok("Erreur", "Pack introuvable :\n" + SRC_REAL)
        return False

    TARGETS = [
        ("skin.arctic.fuse.2/",
         "special://home/userdata/addon_data/skin.arctic.fuse.2/"),

        ("script.skinvariables/",
         "special://home/userdata/addon_data/script.skinvariables/"),
    ]

    for rel_src, dst in TARGETS:
        src = SRC_ROOT + rel_src
        src_real = xbmcvfs.translatePath(src)
        dst_real = xbmcvfs.translatePath(dst)

        if not xbmcvfs.exists(src_real):
            ok("Source manquante", "Introuvable :\n" + src_real)
            return False

        copy_tree(src_real, dst_real)

    # Rafraîchit SkinVariables
    xbmc.executebuiltin("RunScript(script.skinvariables)")
    xbmc.sleep(800)

    # Petit refresh visuel (Estuary)
    xbmc.executebuiltin("ReloadSkin()")
    xbmc.sleep(1000)

    return True

def apply():
    # Vérif du skin actif
    current_skin = xbmc.getSkinDir()

    # Injection uniquement sous Estuary
    if current_skin != REQUIRED_SKIN:
        ok(
            "Action requise",
            "Pour injecter la config, tu dois être sur Estuary.\n\n"
            "1) Va dans Paramètres > Interface > Skin\n"
            "2) Choisis Estuary\n"
            "3) Relance cet add-on\n\n"
            "Après injection, tu repasseras manuellement sur Arctic Fuse 2."
        )
        return

    if not xbmcgui.Dialog().yesno(
        "Installer Arctic Fuse 2",
        "Tu es sur Estuary \n\n"
        "Lancer l'injection maintenant ?"
    ):
        return

    if not apply_pack():
        return

    ok(
        "Terminé",
        "Config injectée avec succès \n\n"
        "Maintenant : va dans Paramètres > Interface > Skin\n"
        "et repasse manuellement sur Arctic Fuse 2.\n"
        "(Pas besoin de redémarrer.)"
    )

if __name__ == "__main__":
    apply()
